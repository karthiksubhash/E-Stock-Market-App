package com.eStockMarketInfoReadServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockMarketInfoReadServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockMarketInfoReadServicesApplication.class, args);
	}

}
