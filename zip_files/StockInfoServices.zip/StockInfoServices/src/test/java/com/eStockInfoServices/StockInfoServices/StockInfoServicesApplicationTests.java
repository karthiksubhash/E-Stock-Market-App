package com.eStockInfoServices.StockInfoServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockInfoServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
