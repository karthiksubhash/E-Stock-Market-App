package com.eStockInfoServices.StockInfoServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockInfoServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockInfoServicesApplication.class, args);
	}

}
